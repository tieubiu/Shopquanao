str = {
    "Honda Vision":"jjj",
    "Honda Air Blade":"kkkk"

};
tmp = (Object.keys(str)[0]).split(' ');
console.log(tmp[0]);